INSERT INTO workers VALUES('PB1','Ramesh','8523695147','PB',true,10);
INSERT INTO workers VALUES('EC1','Suresh','7469258145','EC',false,16);
INSERT INTO workers VALUES('CP1','Mukesh','7895741826','CP',true,8);
INSERT INTO workers VALUES('PB2','Ambani','9598362145','PB',false,15);
INSERT INTO workers VALUES('CL1','Ramu','8521436259','CL',true,14);
INSERT INTO workers VALUES('EC2','Sharma','9625147836','EC',true,25);
INSERT INTO workers VALUES('CL2','Shreyas','9558471114','CL',true,17);
INSERT INTO workers VALUES('LA1','Rakesh','6522415786','LA',true,12);