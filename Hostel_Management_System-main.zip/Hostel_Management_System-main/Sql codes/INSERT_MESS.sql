INSERT INTO Mess VALUES('mb1','IFCA',115,'Dr.Kishore','Suresh');
INSERT INTO Mess VALUES('mb2','IFCB',115,'Dr.Raghu','Arun');
INSERT INTO Mess VALUES('mb3','IFCC',115,'Dr.Yousuf','Srikanth');
INSERT INTO Mess VALUES('mg1','IFCG',115,'Dr.Vennela','Sujatha');