INSERT INTO Hostel VALUES('hst1','Ultra Mega',1800,10000,'male');
INSERT INTO Hostel VALUES('hst2','Mega',1000,9000,'male');
INSERT INTO Hostel VALUES('4blk','Block 4',48,9500,'male');
INSERT INTO Hostel VALUES('6blk','Block 6',48,9500,'male');
INSERT INTO Hostel VALUES('3blk','Block 3',48,9500,'male');
INSERT INTO Hostel VALUES('LHA','Ladies A',500,12500,'female');
INSERT INTO Hostel VALUES('LHB','Ladies B',500,12500,'female');
INSERT INTO Hostel VALUES('LHC','Ladies C',500,12500,'female');