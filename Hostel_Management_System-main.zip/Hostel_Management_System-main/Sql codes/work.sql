CREATE TABLE Work(
	Work_dept_id Varchar(10) PRIMARY KEY,
    Dept_name varchar(10) NOT NULL
)