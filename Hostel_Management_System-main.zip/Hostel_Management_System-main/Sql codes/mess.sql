CREATE TABLE Mess(
	Mess_id varchar(10) PRIMARY KEY,
    Mess_name varchar(15) NOT NULL,
    Per_day_cost int NOT NULL,
    Mess_incharge varchar(10) NOT NULL,
    Contractor varchar(15) NOT NULL
)