INSERT INTO work VALUES('CP', 'Carpentry');
INSERT INTO work VALUES('CL', 'Cleaning');
INSERT INTO work VALUES('PB', 'Plumber');
INSERT INTO work VALUES('EC', 'Electric');
INSERT INTO work VALUES('LA', 'Lan');