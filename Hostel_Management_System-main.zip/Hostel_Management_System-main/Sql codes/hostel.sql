CREATE TABLE Hostel(
	Hostel_id varchar(10) PRIMARY KEY,
    Hostel_name varchar(10) NOT NULL,
    Rooms_capacity int NOT NULL,
    Annual_fee int NOT NULL,
    Gender varchar(6) NOT NULL
)