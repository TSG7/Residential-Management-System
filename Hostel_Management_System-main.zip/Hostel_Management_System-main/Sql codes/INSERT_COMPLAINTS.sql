INSERT INTO complaints VALUES('cb01','100','PB','A305','hst1','Tap Leakage','PB1',false);
INSERT INTO complaints VALUES('cb02','102','EC','4307','4blk','Fan slow','EC1',true);
INSERT INTO complaints VALUES('cb03','109','LA','3104','3blk','Lan not working','LA1',true);
INSERT INTO complaints VALUES('cb04','110','CL','3225','hst2','Room cleaning','CL1',true);
INSERT INTO complaints VALUES('cb05','105','CP','B101','hst1','Chair broken','CP1',true);
INSERT INTO complaints VALUES('cg01','114','LA','1216','LHA','Lan Port broken','LA1',false);
INSERT INTO complaints VALUES('cg02','116','EC','1312','LHC','Light not working','EC2',false);